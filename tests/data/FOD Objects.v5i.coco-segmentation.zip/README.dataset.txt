# FOD Objects > 2025-02-17 11:22am
https://universe.roboflow.com/reu-6fwuh/fod-objects

Provided by a Roboflow user
License: CC BY 4.0

