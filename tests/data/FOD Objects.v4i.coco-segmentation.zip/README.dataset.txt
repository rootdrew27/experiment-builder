# FOD Objects > 2025-02-08 2:49pm
https://universe.roboflow.com/reu-6fwuh/fod-objects

Provided by a Roboflow user
License: CC BY 4.0

