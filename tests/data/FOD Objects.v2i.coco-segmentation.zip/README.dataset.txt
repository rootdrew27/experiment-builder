# FOD Objects > 2025-01-31 9:06am
https://universe.roboflow.com/reu-6fwuh/fod-objects

Provided by a Roboflow user
License: CC BY 4.0

